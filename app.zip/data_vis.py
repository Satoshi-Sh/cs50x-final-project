import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import manage_graphs
plt.style.use('fivethirtyeight')


#test_data = [{'name': 'George Lucas', 'title': 'THX 1138', 'rating': 6.7, 'year': 1971}, {'name': 'George Lucas', 'title': 'American Graffiti', 'rating': 7.4, 'year': 1973}, {'name': 'George Lucas', 'title': 'Star Wars: Episode IV - A New Hope', 'rating': 8.6, 'year': 1977}, {'name': 'George Lucas', 'title': 'Star Wars: Episode I - The Phantom Menace', 'rating': 6.5, 'year': 1999}, {'name': 'George Lucas', 'title': 'Star Wars: Episode II - Attack of the Clones', 'rating': 6.5, 'year': 2002}, {'name': 'George Lucas', 'title': 'Star Wars: Episode III - Revenge of the Sith', 'rating': 7.5, 'year': 2005}]
year_average = {1970: 6.04, 1971: 5.96, 1972: 5.96, 1973: 5.98, 1974: 5.99, 1975: 6.02, 1976: 6.05, 1977: 6.09, 1978: 6.1, 1979: 6.08, 1980: 6.03, 1981: 6.09, 1982: 6.02, 1983: 5.97, 1984: 6.05, 1985: 6.05, 1986: 5.98, 1987: 5.97, 1988: 5.93, 1989: 5.97, 1990: 5.96, 1991: 6.02, 1992: 5.99, 1993: 5.97, 1994: 6.0, 1995: 5.95, 1996: 6.05, 1997: 6.08, 1998: 6.03, 1999: 6.03, 2000: 6.03, 2001: 6.11, 2002: 6.2, 2003: 6.16, 2004: 6.22, 2005: 6.23, 2006: 6.18, 2007: 6.24, 2008: 6.22, 2009: 6.21, 2010: 6.22, 2011: 6.25, 2012: 6.28, 2013: 6.26, 2014: 6.27, 2015: 6.26, 2016: 6.25, 2017: 6.27, 2018: 6.17, 2019: 6.15, 2020: 6.18, 2021: 6.37}

def make_vis(data):
    if len(data) ==0:
        return "No Data Found"
    fig,ax = plt.subplots(figsize=(20,16))
    director = data[0]['name'].replace(' ','_')
    df = pd.DataFrame([d for d in data])
    sns.lineplot(data=df, x='year', y='rating',marker='o',markersize=15, ax=ax)
    plt.title(director,fontsize=29)
    for x,y,m in df[['year','rating','title']].values:
        #some titles are too long to fit in
        m = m.split(' - ')[0]
        ax.text(x+0.5,y,f'{m}')
    start = data[0]['year']
    end = data[-1]['year']
    avgs =[]
    for i in range(start,end+1):
        avgs.append({'year':i, 'rating':year_average[i]})
    avg_df = pd.DataFrame([avg for avg in avgs])
    sns.lineplot(data=avg_df, x='year', y='rating',marker='o',markersize=15, ax=ax)
    plt.savefig(f'static/graphs/{director}.png')
    manage_graphs.delete_old()
    return f'static/graphs/{director}'
#make_vis(test_data)