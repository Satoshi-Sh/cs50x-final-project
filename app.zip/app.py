import os

import sqlite3
from flask import Flask, flash, jsonify, redirect, render_template, request, session

import data_vis

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Configure database
#to make the row dictionary
def dict_factory(cursor, row):
    d = {}
    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]
    return d

def db_ready():
    con = sqlite3.connect('movies.db')
    con.row_factory = dict_factory
    cur = con.cursor()
    return cur
# rotten tomatoes year average
year_average = {1970: 6.04, 1971: 5.96, 1972: 5.96, 1973: 5.98, 1974: 5.99, 1975: 6.02, 1976: 6.05, 1977: 6.09, 1978: 6.1, 1979: 6.08, 1980: 6.03, 1981: 6.09, 1982: 6.02, 1983: 5.97, 1984: 6.05, 1985: 6.05, 1986: 5.98, 1987: 5.97, 1988: 5.93, 1989: 5.97, 1990: 5.96, 1991: 6.02, 1992: 5.99, 1993: 5.97, 1994: 6.0, 1995: 5.95, 1996: 6.05, 1997: 6.08, 1998: 6.03, 1999: 6.03, 2000: 6.03, 2001: 6.11, 2002: 6.2, 2003: 6.16, 2004: 6.22, 2005: 6.23, 2006: 6.18, 2007: 6.24, 2008: 6.22, 2009: 6.21, 2010: 6.22, 2011: 6.25, 2012: 6.28, 2013: 6.26, 2014: 6.27, 2015: 6.26, 2016: 6.25, 2017: 6.27, 2018: 6.17, 2019: 6.15, 2020: 6.18, 2021: 6.37}

# how much score the director get compared to the average of the year
def get_score(data):
    sum = 0
    for i in data:
        sum += i['rating'] - year_average[i['year']]
    if len(data) == 0:
        return "No Data Found"
    avg =  sum / len(data)
    result = ''
    if avg < -1:
        # worst
        result += '<i class="bi bi-emoji-dizzy text-danger"></i>'
    elif avg < -0.5:
        # worse
        result += '<i class="bi bi-emoji-frown text-info"></i>'
    elif avg < 0.3:
        # Not good
        result += '<i class="bi bi-emoji-expressionless text-warning"></i>'
    elif avg < 1:
        result += '<i class="bi bi-emoji-sunglasses text-primary"></i>'
    else:
        result += '<i class="bi bi-emoji-heart-eyes text-success"></i>'
    return result

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        director = request.form.get('director')
        # To get directors movie titles
        cursor = db_ready()
        cursor.execute("SELECT p.name, m.title, r.rating, m.year FROM people AS p, movies AS m, ratings AS r,\
           directors AS d WHERE p.name= '{director}' AND p.id = d.person_id AND d.movie_id = m.id AND m.id = r.movie_id ORDER BY year;"\
            .format(director = director))
        movies = cursor.fetchall()
        score = get_score(movies)
        cursor.close()
        path = data_vis.make_vis(movies)
        if path == "No Data Found":
            return render_template("index.html", movies= movies, message= "No data found")
        return render_template("index.html", movies= movies, avg= year_average, path = path, score=score)
    else:
        return render_template("index.html")

# function for suggestion
@app.route("/search", methods=["GET"])
def search():
    word = request.args.get('q')
    cursor = db_ready()
    cursor.execute("SELECT DISTINCT name FROM people AS p, directors\
         AS d WHERE person_id=id AND name LIKE '%{word}%' LIMIT 8".format(word=word))
    directors = cursor.fetchall()
    cursor.close()

    return jsonify(directors)

# function for director suggestion from titles
@app.route('/search2', methods=['GET'])
def search2():
    word = request.args.get('q')
    cursor = db_ready()
    cursor.execute('SELECT DISTINCT m.title, p.name  FROM movies AS m,directors AS d,\
        people AS p  WHERE m.id = d.movie_id AND p.id =d.person_id AND m.title LIKE "%{word}%" LIMIT 10'.format(word=word))
    titles = cursor.fetchall()
    cursor.close()
    return jsonify(titles)

# function for director suggestion from actor
@app.route('/search3', methods=["GET"])
def search3():
    word = request.args.get('q')
    cursor = db_ready()
    cursor.execute('SELECT DISTINCT p.name FROM people AS p,stars AS s WHERE p.name LIKE "%{word}%" AND\
            p.id =s.person_id LIMIT 10;'.format(word=word))
    actors = cursor.fetchall()
    cursor.close()
    return jsonify(actors)


# for page look up director name from movie titles
@app.route("/find",methods=["GET",'POST'])
def find():
    return render_template('find.html')

# for page look up director name from actors
@app.route("/actors",methods=["GET","POST"])
def actors():
    if request.method == 'POST':
        actor = request.form.get('actor')
        cursor = db_ready()
        cursor.execute('SELECT m.title, m.year, p.name FROM movies AS m, directors AS d, people AS p  WHERE m.id = d.movie_id AND d.person_id= p.id AND m.id\
              IN (SELECT s.movie_id FROM people AS p,stars AS s WHERE name = "{actor}" AND p.id =s.person_id) ORDER BY m.year;'.format(actor=actor))
        data = cursor.fetchall()
        cursor.close()
        if len(data) ==0:
            return render_template("actors.html",data=data, actor=actor, message='No data found')
        return render_template("actors.html",data=data, actor=actor)
    return render_template("actors.html")