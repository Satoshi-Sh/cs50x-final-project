import os
import glob

path = "./static/graphs/*.png"

def delete_old():
    if (len(glob.glob(path))>5):
        oldest = sorted(glob.glob(path),key=os.path.getctime)[0]
        os.remove(oldest)
        file = oldest.split('/')[-1]
        return print(f"{file} deleted")
    return print("No file deleted")